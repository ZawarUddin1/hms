<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Departmentm extends CI_Model
{

    function __construct() {
        parent::__construct();
        $this->load->database();
    }

    function __destruct() {
        $this->db->close();
    }
}
?>