<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Loginm extends CI_Model
{

    function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function validate($name,$password) {
        $this->db->select('*');
        $this->db->where('username',$name);
        $this->db->where('password',$password);
        return $this->db->get('users')->row();
    }

    public function insert($data) {
        $query = $this->db->insert("users",$data);
        if ($query) {
            return true;
        } else {
            return false;
        }
    }
    function __destruct() {
        $this->db->close();
    }
}
?>