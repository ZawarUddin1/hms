<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Treatment extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */

	public function __construct() {
        parent::__construct();
        $this->load->library('session');
		$this->load->model('treatmentm');
    }

	public function index(){
        // var_dump($_SESSION);
        if (isset($_SESSION['username'])) {
            $treat_list['treat_list'] = $this->treatmentm->get_wards_list();
		    $this->load->view('treatment',$treat_list);
        }else{
            $this->session->set_Flashdata('message', 'Not allowed!');
            redirect('welcome');    
        }   
	}
	
	public function search(){
	    $dep_id = $_POST['dep_id'];
	    $doc_id = $_POST['doc_id'];
	    
	    $treat_list['treat_list'] = $this->treatmentm->get_list($dep_id,$doc_id);
	    $treat_list['dep_id'] = $_POST['dep_id'] ? $dep_id : 0;
	    $treat_list['doc_id'] = $_POST['doc_id'] ? $doc_id : 0;
		$this->load->view('treatment',$treat_list);
	}
	
	public function get_ward_list(){
	    $details = $this->treatmentm->get_ward_list();
	    echo JSON_encode($details);
	}
	public function update(){
	   // echo'<pre>';print_r($_POST);die;
	    if($_POST){
	        $data = array(
	        'doctor_id' => $_POST['doc_id'],
	        'bed_id' => 2,
	        'patient_id' => $_POST['pat_id'],
	        'created_date' => date('Y-m-d')
	        );
	        $this->db->insert('treatment_record',$data);
	        $insert_id = $this->db->insert_id();
	        
	        $patient_id = $_POST['pat_id'];
	        $ward_id = $_POST['ward_id'];
	        $admission = $_POST['admission_date'];
	        $tr_id = $insert_id;
	        $bed_id = 2;
	        
	        $this->treatmentm->update_pat($patient_id,$ward_id,$tr_id,$bed_id,$admission);
	        redirect('patient/index');
	    }
	   //print_r($_POST);
	}
	
	public function get_ward_details(){
	    $ward_id = $_GET['ward_id'];
	    $details = $this->treatmentm->get_details($ward_id);
	    echo JSON_encode($details);
	}
	
	public function get_patients(){
	    $ward_id = $_GET['ward_id'];
	    $list = $this->treatmentm->get_patients($ward_id);
	    echo JSON_encode($list);
	}
}
