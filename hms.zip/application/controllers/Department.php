<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Department extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */

	public function __construct() {
        parent::__construct();
        $this->load->library('session');
		$this->load->model('departmentm');
    }

	public function index(){
        // var_dump($_SESSION);
        if (isset($_SESSION['username'])) {
			$list['list'] = $this->departmentm->get_list();
		    $this->load->view('department',$list);
        }else{
            $this->session->set_Flashdata('message', 'Not allowed!');
            redirect('welcome');    
        }   
	}

	public function add(){
		if($_POST){
			$date = date('Y-m-d');
			$data = array(
				'name' => $_POST['name'],
				'short_code' => $_POST['short_code'],
				'doctor_id' => $_POST['doctor_id'],
				'status' => $_POST['status'],
				'created_date' => $date
			);
			
			if(!empty($data)){
				$this->departmentm->add_department($data);
				redirect('department/index');
			}
		}
	}

	public function add_beds(){
		if($_POST){
			$date = date('Y-m-d');
			$data = array(
				'ward_id' => $_POST['dep_id'],
				'bed_number' => $_POST['bed_number'],
				'status' => '1',
				'created_date' => $date
			);
			if(!empty($data)){
				$this->departmentm->add_bed($data);
				redirect('department/index');
			}
		}
	}
	
	public function get_beds_list(){
	    $dep_id = $_GET['ward_id'];
	    $bed_list = $this->departmentm->get_beds_list($dep_id);
	    echo JSON_encode($bed_list);
	}
}
