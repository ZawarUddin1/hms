<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Doctor extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */

	public function __construct() {
        parent::__construct();
        $this->load->library('session');
		$this->load->model('doctorm');
    }

	public function index(){
        // var_dump($_SESSION);
        if (isset($_SESSION['username'])) {
			$doc_list['docs_list'] = $this->doctorm->get_list();
		    $this->load->view('doctor',$doc_list);
        }else{
            $this->session->set_Flashdata('message', 'Not allowed!');
            redirect('welcome');    
        }   
	}
	public function add(){
		if($_POST){
			$date = date('Y-m-d');
			$user_data = array(
				'username' => $_POST['username'],
				'password' => $_POST['password'],
				'status' => '1',
				'created_date' => $date
			);
			if(!empty($user_data)){
				$this->db->insert('users', $user_data);
				$insert_id = $this->db->insert_id();
			}
			$data = array(
				'user_id' => $insert_id,
				'name' => $_POST['name'],
				'email' => $_POST['email'],
				'username' => $_POST['username'],
				'gender' => $_POST['gender'],
				'address' => $_POST['address'],
				'country' => $_POST['country'],
				'city' => $_POST['city'],
				'postal_code' => $_POST['postal_code'],
				'phone' => $_POST['phone'],
				'dep_id' => $_POST['dep_id'],
				'status' => '1',
				'right_id' => 2,
				'joining_date' => $date,
				'created_date' => $date
			);
			if(!empty($data)){
				$doc = $this->doctorm->add_doctor($data);
				redirect('doctor/index');
			}
		}
	}
	
	public function get_list(){
	    $dep_id = $_GET['dep_id'];
	    if($dep_id){
    	    $doc_list = $this->doctorm->get_list($dep_id);
	    }else{
	        $doc_list = $this->doctorm->get_list();
	    }
	    echo JSON_encode($doc_list);
	}
}
