<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Patient extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */

	public function __construct() {
        parent::__construct();
        $this->load->library('session');
		$this->load->model('patientm');
    }

	public function index(){
        // var_dump($_SESSION);
        if (isset($_SESSION['username'])) {
			$list['list'] = $this->patientm->get_list();
		    $this->load->view('patient',$list);
        }else{
            $this->session->set_Flashdata('message', 'Not allowed!');
            redirect('welcome');    
        }   
	}

	public function add(){
	   // echo'<pre>';print_r($_POST);die;
		if($_POST){
			$date = date('Y-m-d');
			$user_data = array(
				'username' => $_POST['username'],
				'password' => $_POST['password'],
				'status' => '1',
				'created_date' => $date
			);
			if(!empty($user_data)){
				$this->db->insert('users', $user_data);
				$insert_id = $this->db->insert_id();
			}
			
			
			if($_POST['formSelect'] == 1){
			$data = array(
				'user_id' => $insert_id,
				'name' => $_POST['name'],
				'email' => $_POST['email'],
				'username' => $_POST['username'],
				'gender' => $_POST['gender'],
				'present_address' => $_POST['address'],
				'permanent_address' => $_POST['address'],
				'country' => 0,
				'city' => $_POST['city'],
				'postal_code' => $_POST['postal_code'],
				'ward_id' => $_POST['ward_id'],
				'bed_id' => $_POST['bed_id'],
				'phone_number' => $_POST['phone'],
				'admission_date' => $date,
				'age' => $_POST['age'],
				'status' => '1',
				'right_id' => 3,
				'created_date' => $date
			);
			}else{
			   $data = array(
				'user_id' => $insert_id,
				'name' => $_POST['name'],
				'email' => $_POST['email'],
				'username' => $_POST['username'],
				'gender' => $_POST['gender'],
				'present_address' => $_POST['address'],
				'permanent_address' => $_POST['address'],
				'country' => 0,
				'city' => $_POST['city'],
				'postal_code' => $_POST['postal_code'],
				'phone_number' => $_POST['phone'],
				'age' => $_POST['age'],
				'bed_id' => 0,
				'status' => '1',
				'right_id' => 3,
				'created_date' => $date
			); 
			}
			
			$this->db->insert('patients', $data);
			$insert_id = $this->db->insert_id();
			
			if($_POST['formSelect'] == 1){
			$tr_data = array(
			    'doctor_id' => $_POST['doctor_id'],
			    'bed_id' => $_POST['bed_id'],
			    'patient_id' => $insert_id
			    );
			}else{
			    $tr_data = array(
			    'doctor_id' => $_POST['doctor_id'],
			    'bed_id' => 0,
			    'patient_id' => $insert_id
			    );
			}
			$this->db->insert('treatment_record', $tr_data);
			$insert_id1 = $this->db->insert_id();
			
			if($insert_id1){
			    $query = "update patients set treatment_id = '$insert_id1' where patient_id = '$insert_id'";
			    if($this->db->query($query)){
			        redirect('patient/index');
			    }
			}
			
// 			if(!empty($data)){
// 				$doc = $this->patientm->add_patient($data);
// 				redirect('patient/index');
// 			}
		}
	}
	
	public function admit(){
	    if($_POST){
	        $date = date('Y-m-d');
	       // echo'<pre>';print_r($_POST);die;
	        $data = array(
	            'doctor_id' => $_POST['doctor_id'],
	            'bed_id' => $_POST['bed_id'],
	            'patient_id' => $_POST['patient_id'],
	            'created_date' => $date
	            );
	            $this->db->insert('treatment_record',$data);
	            $insert_id = $this->db->insert_id();
	            
	       
	            $admission_date = $date;
	            $bed_id = $_POST['bed_id'];
	            $treatment_id = $insert_id;
	            $patient_id = $_POST['patient_id'];
	            
	            $this->patientm->update_pat($patient_id,$admission_date,$bed_id,$treatment_id);
	       redirect('patient/index');
	    }
	}
	
	public function get_patient_details(){
	    $pat_id = $_GET['pat_id'];
	    $details = $this->patientm->get_patient_details($pat_id);
	    echo JSON_encode($details);
	}
	
	public function get_list_docs(){
	    $pat_id = $_GET['pat_id'];
	    $list = $this->patientm->get_list_docs($pat_id);
	    echo JSON_encode($list);
	}
	
	public function discharge(){
	    $pat_id = $_GET['pat_id'];
	    
	    $this->db->where('patient_id', $pat_id);
        $this->db->delete('patients');
        
        $this->db->where('patient_id', $pat_id);
        $this->db->delete('treatment_record');
        
        $delete = "Patient Discharge Successfully";
        
        echo JSON_encode($delete);
	}
}
