<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */

	function __construct() {
        parent::__construct();
        $this->load->library('session');
		$this->load->model('loginm');
    }

	public function index()
	{
		// print_r($this->input->post());
		$username = $this->input->post('username');
		$password = $this->input->post('password');

		$validate = $this->loginm->validate($username,$password);
// 		print_r($validate);die;
		if(isset($validate)){
			$data = [
				'username' => $validate->username,
				'status' => $validate->status,
				'login' => true,
				'admin_right_id' => $validate->admin_right_id,
				'doctor_right_id' => $validate->doctor_right_id,
				'patient_right_id' => $validate->patient_right_id,
			];
			$this->session->set_userdata($data);
			redirect('Dashboard');
		}else{
			$mess = 'You are not authorized to login. Contact Administration';
			redirect('welcome');
		}
	}

	public function logout(){
		$this->session->sess_destroy();
		redirect('welcome');
	}
}
