<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('html/head.php')?>

<body> 
    <div class="main-wrapper">
        <?php $this->load->view('html/sidebar.php')?>
        <div class="sidebar" id="sidebar">
            <div class="sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">
                    <ul>
                        <li class="menu-title">Main</li>
                        <?php 
                        $link1 =  base_url('dashboard');
                        $link2 =  base_url('doctor');
                        $link3 =  base_url('patient');
                        $link4 =  base_url('appointment');
                        $link5 =  base_url('schedule');
                        $link6 =  base_url('department');
                        ?>
                        <li class="">
                            <a href="<?php echo base_url('dashboard')?>"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
                        </li>
						<li class="">
                            <a href="<?php echo base_url('doctor')?>"><i class="fa fa-user-md"></i> <span>Doctors</span></a>
                        </li>
                        <li>
                            <a href="<?php echo base_url('patient')?>"><i class="fa fa-wheelchair"></i> <span>Patients</span></a>
                        </li>
                        <!--<li>-->
                        <!--    <a href="<?php echo base_url('appointment')?>"><i class="fa fa-calendar"></i> <span>Appointments</span></a>-->
                        <!--</li>-->
                        <!--<li>-->
                        <!--    <a href="<?php echo base_url('schedule')?>"><i class="fa fa-calendar-check-o"></i> <span>Doctor Schedule</span></a>-->
                        <!--</li>-->
                        <li class="active">
                            <a href="<?php echo base_url('department')?>"><i class="fa fa-hospital-o"></i> <span>Departments</span></a>
                        </li>
                        <li class="">
                            <a href="<?php echo base_url('treatment')?>"><i class="fa fa-hospital-o"></i> <span>Wards</span></a>
                        </li>
						<!-- <li class="submenu">
							<a href="#"><i class="fa fa-flag-o"></i> <span> Reports </span> <span class="menu-arrow"></span></a>
							<ul style="display: none;">
								<li><a href="expense-reports.html"> Expense Report </a></li>
								<li><a href="invoice-reports.html"> Invoice Report </a></li>
							</ul>
						</li>
                        <li>
                            <a href="settings.html"><i class="fa fa-cog"></i> <span>Settings</span></a>
                        </li> -->
                        
                    </ul>
                </div>
            </div>
        </div>
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-sm-5 col-5">
                        <h4 class="page-title">Departments</h4>
                    </div>
                    <div class="col-sm-7 col-7 text-right m-b-30">
                        <a class="btn btn-primary btn-rounded float-right" href="#" data-toggle="modal" data-target="#add_department"><i class="fa fa-plus-o m-r-5"></i> Add Department</a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table class="table table-striped custom-table mb-0 datatable" id="DataTables_Table_0">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Department Name</th>
                                        <th>Code</th>
                                        <th>Incharge</th>
                                        <!--<th>Total Beds</th>-->
                                        <th>Status</th>
                                        <th class="text-right">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $count = 1; foreach($list as $row){
                                        $tot_beds = $this->departmentm->get_tot_beds($row->dep_id);  
                                    ?>
                                    <tr>
                                        <td><?php $count++?></td>
                                        <td><?php echo $row->name?></td>
                                        <td><?php echo $row->short_code?></td>
                                        <td><?php echo $row->incharge?></td>
                                        <!--<td><?php if($tot_beds[0]->tot_bed != null){echo $tot_beds[0]->tot_bed;}else{echo '0';}?></td>-->
										<td>
                                            <?php if($row->status == 1){?>
                                                <span class="custom-badge status-green">Active</span>
                                            <?php }else{?>
                                                <span class="custom-badge status-red">inactive</span>
                                            <?php }?>
                                        </td>
                                        <td class="text-right">
                                            <div class="dropdown dropdown-action">
                                                <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <!--<a class="dropdown-item" href="#" data-toggle="modal" data-target="#add_beds" data-id="<?php echo $row->dep_id?>" data-name="<?php echo $row->name?>"><i class="fa fa-plus m-r-5"></i>Add Wards</a>-->
                                                    <a class="dropdown-item" href="edit-department.html"><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_department"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php }?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<div id="add_department" class="modal fade delete-modal" role="dialog">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content">
                    <div class="modal-header">
                        <h5>Add Department</h5>
                        <a class="btn btn-close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></a>
                    </div>
					<div class="modal-body">
						<div class="col-lg-12">
                            <form action="<?php echo base_url('department/add')?>" method="post" name="add_doc">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Name <span class="text-danger">*</span></label>
                                            <input class="form-control" type="text" name="name" required>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Code <span class="text-danger">*</span></label>
                                            <input class="form-control" type="text" name="short_code" required>
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label>Incharge <span class="text-danger">*</span></label>
                                            <?php $list = $this->doctorm->get_list();
                                                foreach($list as $row){
                                            ?>
                                            <select class="form-control" name="doctor_id">
                                                <option value="<?php echo $row->doc_id?>"><?php echo $row->name?></option>
                                            </select>
                                            <?php }?>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="display-block">Status</label>
                                            <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="status" id="status" value="1" checked>
                                            <label class="form-check-label" for="status">
                                            Active
                                            </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="status" id="status" value="0">
                                            <label class="form-check-label" for="status">
                                            Inactive
                                            </label>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="m-t-20 text-center">
                                    <button class="btn btn-primary submit-btn">Submit</button>
                                </div>
                            </form>
                        </div>        
					</div>
				</div>
			</div>
		</div>
        <div id="add_beds" class="modal fade delete-modal" role="dialog">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content">
                    <div class="modal-header">
                        <h5>Add Beds</h5>
                        <a class="btn btn-close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></a>
                    </div>
					<div class="modal-body">
                        <form action="<?php echo base_url('department/add_beds')?>" method="post" name="add_doc">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Department <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" name="name" id="dep_name" readonly>
                                        <input class="form-control" type="hidden" name="dep_id" id="dep_id" readonly>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Bed Number <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" name="bed_number">
                                    </div>
                                </div>
                            </div>
                            <div class="m-t-20 text-center">
                                <button class="btn btn-primary submit-btn">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="sidebar-overlay" data-reff=""></div>
    <script src="<?php echo base_url('assets/js/jquery-3.2.1.min.js')?>"></script>
	<script src="<?php echo base_url('assets/js/popper.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/jquery.dataTables.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/dataTables.bootstrap4.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/jquery.slimscroll.js')?>"></script>
    <!--<script src="<?php echo base_url('assets/js/app.js')?>"></script>-->
</body>
<script type="text/javascript">
    $('#add_beds').on('show.bs.modal', function(event) {
        var button = $(event.relatedTarget) 
        var id = button.data('id') 
        var name = button.data('name')
        
        var modal = $(this)
        modal.find('.modal-body #dep_name').val(name) 
        modal.find('.modal-body #dep_id').val(id) 

    })
</script>
<script type="text/javascript">
        $('#DataTables_Table_0').DataTable({
            searching: true, // Ensure this is true
            pagging : true
        });
    </script>

<!-- departments23:21-->
</html>