<!DOCTYPE html>
<html lang="en">



<?php $this->load->View('html/head.php')?>

<body>
    <?php //echo'<pre>';
    //print_r($_SESSION['admin_right_id']);
    //die;
    ?>
    <div class="main-wrapper">
       <?php $this->load->view('html/sidebar.php')?>
        <div class="sidebar" id="sidebar">
            <div class="sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">
                    <ul>
                        <li class="menu-title">Main</li>
                        <?php 
                        $link1 =  base_url('dashboard');
                        $link2 =  base_url('doctor');
                        $link3 =  base_url('patient');
                        $link4 =  base_url('appointment');
                        $link5 =  base_url('schedule');
                        $link6 =  base_url('department');
                        ?>
                        <li class="active">
                            <a href="<?php echo base_url('dashboard')?>"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
                        </li>
						<li class="">
                            <a href="<?php echo base_url('doctor')?>"><i class="fa fa-user-md"></i> <span>Doctors</span></a>
                        </li>
                        <li>
                            <a href="<?php echo base_url('patient')?>"><i class="fa fa-wheelchair"></i> <span>Patients</span></a>
                        </li>
                        <!--<li>-->
                        <!--    <a href="<?php echo base_url('appointment')?>"><i class="fa fa-calendar"></i> <span>Appointments</span></a>-->
                        <!--</li>
                        <li>
                            <a href="<?php echo base_url('schedule')?>"><i class="fa fa-calendar-check-o"></i> <span>Doctor Schedule</span></a>
                        </li>-->
                        <li>
                            <a href="<?php echo base_url('department')?>"><i class="fa fa-hospital-o"></i> <span>Departments</span></a>
                        </li>
                        <li class="">
                            <a href="<?php echo base_url('treatment')?>"><i class="fa fa-hospital-o"></i> <span>Wards</span></a>
                        </li>
						<!-- <li class="submenu">
							<a href="#"><i class="fa fa-flag-o"></i> <span> Reports </span> <span class="menu-arrow"></span></a>
							<ul style="display: none;">
								<li><a href="expense-reports.html"> Expense Report </a></li>
								<li><a href="invoice-reports.html"> Invoice Report </a></li>
							</ul>
						</li>
                        <li>
                            <a href="settings.html"><i class="fa fa-cog"></i> <span>Settings</span></a>
                        </li> -->
                        
                    </ul>
                </div>
            </div>
        </div>
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
                        <div class="dash-widget">
							<span class="dash-widget-bg1"><i class="fa fa-stethoscope" aria-hidden="true"></i></span>
							<div class="dash-widget-info text-right">
								<?php $tot_docs = $this->dashboardm->get_tot_docs()?><h3><?php echo $tot_docs[0]->tot_docs;?></h3>
								<span class="widget-title1">Doctors <i class="fa fa-check" aria-hidden="true"></i></span>
							</div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
                        <div class="dash-widget">
                            <span class="dash-widget-bg2"><i class="fa fa-user-o"></i></span>
                            <div class="dash-widget-info text-right">
                                <?php $tot_pats = $this->dashboardm->get_tot_pat()?><h3><?php echo $tot_pats[0]->tot_pats;?></h3>
                                <span class="widget-title2">Patients <i class="fa fa-check" aria-hidden="true"></i></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
                        <div class="dash-widget">
                            <span class="dash-widget-bg3"><i class="fa fa-hospital-o" aria-hidden="true"></i></span>
                            <div class="dash-widget-info text-right">
                                <?php $tot_deps = $this->dashboardm->get_tot_deps()?><h3><?php echo $tot_deps[0]->tot_deps;?></h3>
                                <span class="widget-title3">Departments <i class="fa fa-check" aria-hidden="true"></i></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
                        <div class="dash-widget">
                            <span class="dash-widget-bg4"><i class="fa fa-bed" aria-hidden="true"></i></span>
                            <div class="dash-widget-info text-right">
                                <?php $tot_admits = $this->dashboardm->get_tot_admits()?><h3><?php echo $tot_admits[0]->tot_admits;?></h3>
                                <span class="widget-title4">Admits <i class="fa fa-check" aria-hidden="true"></i></span>
                            </div>
                        </div>
                    </div>
                </div>
				
				<!--<div class="row">-->
				<!--	<div class="col-12 col-md-10 col-lg-12 col-xl-12">-->
				<!--		<div class="card">-->
				<!--			<div class="card-header">-->
				<!--				<h4 class="card-title d-inline-block">Upcoming Appointments</h4> <a href="appointments.html" class="btn btn-primary float-right">View all</a>-->
				<!--			</div>-->
				<!--			<div class="card-body p-0">-->
				<!--				<div class="table-responsive">-->
				<!--					<table class="table mb-0">-->
				<!--						<thead class="d-none">-->
				<!--							<tr>-->
				<!--								<th>Patient Name</th>-->
				<!--								<th>Doctor Name</th>-->
				<!--								<th>Timing</th>-->
				<!--								<th class="text-right">Status</th>-->
				<!--							</tr>-->
				<!--						</thead>-->
				<!--						<tbody>-->
				<!--							<tr>-->
				<!--								<td style="min-width: 200px;">-->
				<!--									<a class="avatar" href="profile.html">B</a>-->
				<!--									<h2><a href="profile.html">Bernardo Galaviz <span>New York, USA</span></a></h2>-->
				<!--								</td>                 -->
				<!--								<td>-->
				<!--									<h5 class="time-title p-0">Appointment With</h5>-->
				<!--									<p>Dr. Cristina Groves</p>-->
				<!--								</td>-->
				<!--								<td>-->
				<!--									<h5 class="time-title p-0">Timing</h5>-->
				<!--									<p>7.00 PM</p>-->
				<!--								</td>-->
				<!--								<td class="text-right">-->
				<!--									<a href="appointments.html" class="btn btn-outline-primary take-btn">Take up</a>-->
				<!--								</td>-->
				<!--							</tr>-->
											
				<!--						</tbody>-->
				<!--					</table>-->
				<!--				</div>-->
				<!--			</div>-->
				<!--		</div>-->
				<!--	</div>-->
                    
				<!--</div>-->
				<div class="row">
					<div class="col-12 col-md-10 col-lg-12 col-xl-12">
						<div class="card">
							<div class="card-header">
								<h4 class="card-title d-inline-block">New Patients in last 5days </h4> <a href="<?php echo base_url('patient/index')?>" class="btn btn-primary float-right">View all</a>
							</div>
							<div class="card-block">
								<div class="table-responsive">
									<table class="table mb-0 new-patient-table">
										<tbody>
										    <?php
										    $new_pats = $this->dashboardm->get_new_patients();
										    foreach($new_pats as $row){
										    ?>
											<tr>
												<td>
													<img width="28" height="28" class="rounded-circle" src="assets/img/user.jpg" alt=""> 
													<h2><?php echo $row->name?></h2>
												</td>
												<td><?php echo $row->email?></td>
												<td><?php echo $row->phone_number?></td>
												<td><?php echo date('d-M-Y',strtotime($row->created_date))?></td>
											</tr>
											<?php }?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
					
            </div>
            <div class="notification-box">
                <div class="msg-sidebar notifications msg-noti">
                    <div class="topnav-dropdown-header">
                        <span>Messages</span>
                    </div>
                    <div class="drop-scroll msg-list-scroll" id="msg_list">
                        <ul class="list-box">
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">R</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author">Richard Miles </span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item new-message">
                                        <div class="list-left">
                                            <span class="avatar">J</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author">John Doe</span>
                                            <span class="message-time">1 Aug</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">T</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author"> Tarah Shropshire </span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">M</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author">Mike Litorus</span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">C</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author"> Catherine Manseau </span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">D</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author"> Domenic Houston </span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">B</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author"> Buster Wigton </span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">R</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author"> Rolland Webber </span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">C</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author"> Claire Mapes </span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">M</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author">Melita Faucher</span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">J</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author">Jeffery Lalor</span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">L</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author">Loren Gatlin</span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="chat.html">
                                    <div class="list-item">
                                        <div class="list-left">
                                            <span class="avatar">T</span>
                                        </div>
                                        <div class="list-body">
                                            <span class="message-author">Tarah Shropshire</span>
                                            <span class="message-time">12:28 AM</span>
                                            <div class="clearfix"></div>
                                            <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="topnav-dropdown-footer">
                        <a href="chat.html">See all messages</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="sidebar-overlay" data-reff=""></div>
    <script src="<?php echo base_url('assets/js/jquery-3.2.1.min.js')?>"></script>
	<script src="<?php echo base_url('assets/js/popper.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/jquery.slimscroll.js')?>"></script>
    <script src="<?php echo base_url('assets/js/Chart.bundle.js')?>"></script>
    <script src="<?php echo base_url('assets/js/chart.js')?>"></script>
    <script src="<?php echo base_url('assets/js/app.js')?>"></script>

</body>



</html>