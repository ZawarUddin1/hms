<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('html/head.php')?>


<body>
    <div class="main-wrapper">
        <?php $this->load->view('html/sidebar.php')?>
        <div class="sidebar" id="sidebar">
            <div class="sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">
                    <ul>
                        <li class="menu-title">Main</li>
                        <?php 
                        $link1 =  base_url('dashboard');
                        $link2 =  base_url('doctor');
                        $link3 =  base_url('patient');
                        $link4 =  base_url('appointment');
                        $link5 =  base_url('schedule');
                        $link6 =  base_url('department');
                        ?>
                        <li class="">
                            <a href="<?php echo base_url('dashboard')?>"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
                        </li>
						<li class="">
                            <a href="<?php echo base_url('doctor')?>"><i class="fa fa-user-md"></i> <span>Doctors</span></a>
                        </li>
                        <li>
                            <a href="<?php echo base_url('patient')?>"><i class="fa fa-wheelchair"></i> <span>Patients</span></a>
                        </li>
                        <!--<li>-->
                        <!--    <a href="<?php echo base_url('appointment')?>"><i class="fa fa-calendar"></i> <span>Appointments</span></a>-->
                        <!--</li>-->
                        <!--<li class="">-->
                        <!--    <a href="<?php echo base_url('schedule')?>"><i class="fa fa-calendar-check-o"></i> <span>Doctor Schedule</span></a>-->
                        <!--</li>-->
                        <li>
                            <a href="<?php echo base_url('department')?>"><i class="fa fa-hospital-o"></i> <span>Departments</span></a>
                        </li>
                        <li class="active">
                            <a href="<?php echo base_url('treatment')?>"><i class="fa fa-hospital-o"></i> <span>Wards</span></a>
                        </li>
						<!-- <li class="submenu">
							<a href="#"><i class="fa fa-flag-o"></i> <span> Reports </span> <span class="menu-arrow"></span></a>
							<ul style="display: none;">
								<li><a href="expense-reports.html"> Expense Report </a></li>
								<li><a href="invoice-reports.html"> Invoice Report </a></li>
							</ul>
						</li>
                        <li>
                            <a href="settings.html"><i class="fa fa-cog"></i> <span>Settings</span></a>
                        </li> -->
                        
                    </ul>
                </div>
            </div>
        </div>
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-sm-4 col-3">
                        <h4 class="page-title">Treatment Records</h4>
                    </div>
                    <div class="col-sm-8 col-9 text-right m-b-20">
                        <!--<a href="#" class="btn btn btn-primary btn-rounded float-right" data-toggle="modal" data-target="#admit_patient"><i class="fa fa-plus"></i> Admit Patient</a>-->
                    </div>
                </div>
                <!--<div class="row table-info">-->
                <!--    <div class="col-lg-12">-->
                <!--        <form action="<?php echo base_url('treatment/search')?>" method="post" name="addmit">-->
                <!--            <div class="row">-->
                <!--                <div class="col-sm-3">-->
                <!--                    <div class="form-group">-->
                <!--                        <label>Search By Department </label>-->
                <!--                        <select class="form-control" name="dep_id">-->
                <!--                            <option></option>-->
                                            <?php 
                                            // $dep_id = $_POST['dep_id'] ? $_POST['dep_id'] : 0;
                                            // $get_pats = $this->departmentm->get_list();
                                            // foreach($get_pats as $row){
                                            ?>
                                            <!--<option value="<?php echo $row->dep_id?>" <?php if($row->dep_id == $dep_id){echo 'selected="selected"';}?>><?php echo $row->name.' / '.$row->short_code?></option>-->
                                            <?php //}?>
                                <!--        </select>-->
                                <!--    </div>-->
                                <!--</div>-->
                                <!--<div class="col-sm-3">-->
                                <!--    <div class="form-group">-->
                                <!--        <label>Search By Doctor </label>-->
                                <!--        <select class="form-control" name="doc_id">-->
                                <!--            <option></option>-->
                                            <?php 
                                            // $doc_id = $_POST['doc_id'] ? $_POST['doc_id'] :'';
                                            // $get_pats = $this->doctorm->get_list();
                                            // foreach($get_pats as $row){
                                            ?>
                                            <!--<option value="<?php echo $row->doc_id?>" <?php if($row->doc_id == $doc_id){echo 'selected="selected"';}?>><?php echo $row->name?></option>-->
                                            <?php //}?>
                <!--                        </select>-->
                <!--                    </div>-->
                <!--                </div>-->
                <!--                <div class="form-group text-center" style="margin-top:33px !important">-->
                <!--                    <button class="btn btn-secondary">Get Result</button>-->
                <!--                </div>-->
                <!--            </div>-->
                <!--        </form>-->
                <!--    </div>-->
                <!--</div>-->
				<div class="row">
					<div class="col-md-12">
						<div class="table-responsive">
							<table class="table table-border table-striped custom-table datatable mb-0" id="DataTables_Table_0">
								<thead>
									<tr>
										<th>Name</th>
										<th>Department</th>
										<th>Doctor</th>
										
									</tr>
								</thead>
								<tbody>
								    <?php foreach($treat_list as $row){?>
									<tr>
										<td><a class="" href="#" data-toggle="modal" data-target="#admit_patient" data-id="<?php echo $row->ward_id?>"><?php echo $row->name?></a></td>
										<td><?php echo $row->dep_name?></td>
										<td><?php echo $row->doc_name?></td>
										
									</tr>
									<?php }?>
								</tbody>
							</table>
						</div>
                </div>
                </div>
            </div>
        </div>
        
        <div id="admit_patient" class="modal fade" role="dialog">
			<div class="modal-dialog modal-dialog-centered" style="max-width:800px">
				<div class="modal-content">
                    <div class="modal-header">
                        <h5>Ward Details</h5>
                        <a class="btn btn-close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></a>
                    </div>
                    
					<div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card-box">
                                    <form action="#">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-md-4 col-form-label"> Ward Name</label>
                                                    <div class="col-md-8" id="">
                                                        <span id="wardName"></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-md-3 col-form-label"> Type</label>
                                                    <div class="col-md-9">
                                                        <span id="wardType"></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-md-4 col-form-label"> Total Beds</label>
                                                    <div class="col-md-8" id="">
                                                        <span id="noBeds"></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-md-4 col-form-label"> Ward Available</label>
                                                    <div class="col-md-8">
                                                        <span id="wardStatus"></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row" style="border:1px solid #e9ecef;border-radius: 25px;">
                                            <div class="col-md-12"><br>
                                                <h5 class="">List of Patients in Ward</h5><br>
                                                <table class="table table-border table-striped custom-table mm1">
                                                    <thead>
                                                        <th>Patient Name</th>
                                                        <th>Age</th>
                                                        <th>Bed Number</th>
                                                    </thead>
                                                    <tbody id="">
                                                        
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
		</div>
        
		<div id="delete_schedule" class="modal fade delete-modal" role="dialog">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content">
					<div class="modal-body text-center">
						<img src="assets/img/sent.png" alt="" width="50" height="46">
						<h3>Are you sure want to delete this Schedule?</h3>
						<div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
							<button type="submit" class="btn btn-danger">Delete</button>
						</div>
					</div>
				</div>
			</div>
		</div>
    </div>
    <div class="sidebar-overlay" data-reff=""></div>
    <script src="<?php echo base_url('assets/js/jquery-3.2.1.min.js')?>"></script>
	<script src="<?php echo base_url('assets/js/popper.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/jquery.slimscroll.js')?>"></script>
    <script src="<?php echo base_url('assets/js/select2.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/jquery.dataTables.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/dataTables.bootstrap4.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/moment.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap-datetimepicker.min.js')?>"></script>
    <!--<script src="<?php echo base_url('assets/js/app.js')?>"></script>-->
    
    <script type="text/javascript">
        $(document).ready(function(){
            $('#docs_list').hide();
            $('#beds_list').hide();
        });
        function show_fields(){
            $('#docs_list').show();
            $('#beds_list').show();
            $('#usersList').empty();
            $('#bedsList').empty();
            var vall = document.getElementById("selected_id").value;
            //for doctors list
            $.ajax({
                type: 'GET',
                url: '<?php echo base_url("doctor/get_list")?>',
                contentType: "application/json",
                data: {'dep_id' : vall},
                success: function(result) {
                    parsedobj = JSON.parse(result)
                    var appenddata='';
                    appenddata+= "<option></option>";
                    $.each(parsedobj, function(index, value) 
                        {
                            appenddata += "<option value = '" + value.doc_id + "'>" + value.name + " </option>";    
                        });
                        $('#usersList').html(appenddata);
                }
            });
            //for beds list
            $.ajax({
                type: 'GET',
                url: '<?php echo base_url("department/get_beds_list")?>',
                contentType: "application/json",
                data: {'dep_id' : vall},
                success: function(result) {
                    parsedobj1 = JSON.parse(result)
                    var appenddata1='';
                    appenddata1+= "<option></option>";
                    $.each(parsedobj1, function(index, value) 
                        {
                            appenddata1 += "<option value = '" + value.bed_id + "'>" + value.bed_number + " </option>";    
                        });
                        $('#bedsList').html(appenddata1);
                }
            });
        }
        $('#DataTables_Table_0').DataTable({
            searching: true, // Ensure this is true
            pagging : true
        });
        
        $('#admit_patient').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget) 
            var id = button.data('id') 
            
            $.ajax({
                type: 'GET',
                url: '<?php echo base_url("treatment/get_ward_details")?>',
                contentType: "application/json",
                data: {'ward_id' : id},
                success: function(result) {
                    // alert(result);
                    parsedobj1 = JSON.parse(result);
                    // alert(parsedobj1.name);
                    $('#wardName').html(parsedobj1.name);
                    $('#wardType').html(parsedobj1.type);
                    $('#noBeds').html('10');
                    if(parsedobj1.status == 1){
                        $('#wardStatus').html('Available');
                    }else if(parsedobj1.status == 2){
                        $('#wardStatus').html('Not Available');
                    }
                    
                }
            });
            
            $.ajax({
                type: 'GET',
                url: '<?php echo base_url("treatment/get_patients")?>',
                contentType: "application/json",
                data: {'ward_id' : id},
                success: function(result) {
                    // alert(result);
                    parsedobj1 = JSON.parse(result);
                    var row = '';
                    $('.mm1 tbody').empty();
                    $.each(parsedobj1, function(index, value) 
                        {
                            if(value == ''){
                                row += '<tr> No Record Found </tr>';
                            }else{
                                row += '<tr>' +
                                    '<td>' + value.name + '</td>' +
                                    '<td>$' + value.age + '</td>' + // Format currency
                                    '<td>' + value.bed_id + '</td>' +
                                  '</tr>';
                            }
                            
                          
                        });
                        $('.mm1 tbody').append(row); 
                        
                }
            });
        })
    </script>
</body>


<!-- schedule23:21-->
</html>