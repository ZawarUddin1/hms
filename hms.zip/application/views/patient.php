<!DOCTYPE html>
<html lang="en">


<?php  $this->load->view('html/head.php')?>

<body>
    <div class="main-wrapper">
        <?php $this->load->view('html/sidebar.php')?>
        <div class="sidebar" id="sidebar">
            <div class="sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">
                    <ul>
                        <li class="menu-title">Main</li>
                        <?php 
                        $link1 =  base_url('dashboard');
                        $link2 =  base_url('doctor');
                        $link3 =  base_url('patient');
                        $link4 =  base_url('appointment');
                        $link5 =  base_url('schedule');
                        $link6 =  base_url('department');
                        ?>
                        <li class="">
                            <a href="<?php echo base_url('dashboard')?>"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
                        </li>
						<li class="">
                            <a href="<?php echo base_url('doctor')?>"><i class="fa fa-user-md"></i> <span>Doctors</span></a>
                        </li>
                        <li class="active">
                            <a href="<?php echo base_url('patient')?>"><i class="fa fa-wheelchair"></i> <span>Patients</span></a>
                        </li>
                        <!--<li>-->
                        <!--    <a href="<?php echo base_url('appointment')?>"><i class="fa fa-calendar"></i> <span>Appointments</span></a>-->
                        <!--</li>-->
                        <!--<li>-->
                        <!--    <a href="<?php echo base_url('schedule')?>"><i class="fa fa-calendar-check-o"></i> <span>Doctor Schedule</span></a>-->
                        <!--</li>-->
                        <li>
                            <a href="<?php echo base_url('department')?>"><i class="fa fa-hospital-o"></i> <span>Departments</span></a>
                        </li>
                        <li class="">
                            <a href="<?php echo base_url('treatment')?>"><i class="fa fa-hospital-o"></i> <span>Wards</span></a>
                        </li>
						<!-- <li class="submenu">
							<a href="#"><i class="fa fa-flag-o"></i> <span> Reports </span> <span class="menu-arrow"></span></a>
							<ul style="display: none;">
								<li><a href="expense-reports.html"> Expense Report </a></li>
								<li><a href="invoice-reports.html"> Invoice Report </a></li>
							</ul>
						</li>
                        <li>
                            <a href="settings.html"><i class="fa fa-cog"></i> <span>Settings</span></a>
                        </li> -->
                        
                    </ul>
                </div>
            </div>
        </div>
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-sm-4 col-3">
                        <h4 class="page-title">Patients</h4>
                    </div>
                    <div class="col-sm-8 col-9 text-right">
                        <!--<a class="btn btn-success btn-rounded float-right" href="#" data-toggle="modal" data-target="#admit_patient"><i class="fa fa-plus"></i> Admit Patient</a>-->
                        <a class="btn btn-primary btn-rounded float-right" href="#" data-toggle="modal" data-target="#add_patient"><i class="fa fa-plus-o m-r-5"></i> Add Patient</a>
                    </div>
                    </div>
                </div>
				<div class="row">
					<div class="col-md-12">
						<div class="table-responsive">
							<table class="table table-border table-striped custom-table datatable mb-0" id="DataTables_Table_0">
								<thead>
									<tr>
										<th>Name</th>
										<th>Age</th>
										<th>Gender</th>
										<th>Address</th>
										<th>Phone</th>
										<th>Email</th>
										<th>Admitted on</th>
										<th class="text-right">Action</th>
									</tr>
								</thead>
								<tbody>
                                    <?php foreach($list as $row){?>
									<tr <?php if($row->admission_date > 0 && $row->bed_id > 0){ echo 'class="table-warning"';}?>>
										<td><a class="" href="#" data-toggle="modal" data-target="#admit_patient" data-id="<?php echo $row->patient_id?>"><?php echo $row->name?></a></td>
										<td><?php echo $row->age?></td>
										<td><?php if($row->gender == 1) {echo 'M' ;}else{echo 'F';}?></td>
										<td><?php echo $row->permanent_address?></td>
										<td><?php echo $row->phone_number?></td>
										<td><?php echo $row->email?></td>
										<td><?php if($row->admission_date > 0 && $row->bed_id > 0) echo date('d-M-Y',strtotime($row->admission_date));?></td>
										<td class="text-right">
											<?php if($row->admission_date > 0 && $row->bed_id > 0){?>
											<div class="dropdown dropdown-action">
												<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
												<div class="dropdown-menu dropdown-menu-right">
													<a class="dropdown-item" href="#" data-toggle="modal" data-id="<?php echo $row->patient_id?>" data-target="#delete_patient"><i class="fa fa-trash-o m-r-5"></i> Discharge Patient</a>
												</div>
											</div>
											<?php }?>
										</td>
									</tr>
									<?php }?>
								</tbody>
							</table>
						</div>
					</div>
                </div>
                <div class="col-lg-12  text-center">
                    <div class="col-lg-6">&nbsp;</div>
                    <div class="col-lg-4 alert alert-warning">
					    <i class="fa fa-arrow-right"></i> <i>Yellow row respresent for admitted patients</i>
					</div>
				</div>
            </div>
        </div>
        
        <div id="delete_patient" class="modal fade delete-modal" role="dialog">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content">
					<div class="modal-body text-center">
						<img src="assets/img/sent.png" alt="" width="50" height="46">
						<h3>Are you sure want to discharge this Patient?</h3>
						<input type="hidden" id="pat_idd" value="">
						<div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
							<button type="submit" class="btn btn-danger" onclick="deleteRecord()">Yes</button>
						</div>
					</div>
				</div>
			</div>
		</div>
        
		<div id="add_patient" class="modal fade" role="dialog">
			<div class="modal-dialog modal-dialog-centered" style="max-width:1200px">
				<div class="modal-content">
                    <div class="modal-header">
                        <h5>Add Patient</h5>
                        <a class="btn btn-close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></a>
                    </div>
                    
					<div class="modal-body">
                        <div class="col-lg-12">
                            <form action="<?php echo base_url('patient/add')?>" method="post" name="add_doc">
                                <div class="row">
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label>Name <span class="text-danger">*</span></label>
                                            <input class="form-control" type="text" name="name" required>
                                        </div>
                                    </div>
                                    <input class="form-control" type="hidden" name="username" value="PP">
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input class="form-control" type="email" name="email">
                                        </div>
                                    </div>
                                    
                                            <input class="form-control" type="hidden" name="password" value="patient1234">
                                    <div class="col-sm-3">
                                        <div class="form-group gender-select">
                                            <label class="gen-label">Gender:</label>
                                            <div class="form-check-inline">
                                                <label class="form-check-label">
                                                    <input type="radio" name="gender" class="form-check-input" value="1">Male
                                                </label>
                                            </div>
                                            <div class="form-check-inline">
                                                <label class="form-check-label">
                                                    <input type="radio" name="gender" class="form-check-input" value="2">Female
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label>Age</label>
                                            <input class="form-control" type="text" name="age" required>
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label>Phone </label>
                                            <input class="form-control" type="text" name="phone">
                                        </div>
                                    </div>
                                    
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label>City</label>
                                            <input type="text" class="form-control" name="city">
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label>Postal Code</label>
                                            <input type="text" class="form-control" name="postal_code">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Address</label>
                                            <textarea class="form-control" cols="3" rows="3" name="address"></textarea>
                                        </div>                                        
                                    </div>
                                    <div class="col-lg-12" style="border-top:1px solid #e9ecef"></div><br>
                                    </div>
                                    <div class="row">
                                    <div class="col-sm-3">
                                        <div class="form-group">
                                            <label>Department <span class="text-danger">*</span></label>
                                            <select class="form-control" name="dep_id" id="selected_id" onchange="show_fields()">
                                                <option></option>
                                                <?php 
                                                $get_deps = $this->departmentm->get_list();
                                                foreach($get_deps as $row){
                                                ?>
                                                <option value="<?php echo $row->dep_id?>"><?php echo $row->name?></option>
                                                <?php }?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-3" id="">
                                        <div class="form-group">
                                            <label>Doctor <span class="text-danger">*</span></label>
                                            <select class="form-control" name="doctor_id" id="usersList">
                                                <option></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <h5>Do you want to register this patient?</h5><br>
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="radio" name="formSelect" class="form-check-input" id="yes" value="1" onchange="show_form_yes()">Yes
                                        </label>
                                    </div>
                                    <div class="form-check-inline">
                                        <label class="form-check-label">
                                            <input type="radio" name="formSelect" class="form-check-input" id="no" value="2" onchange="show_form_no()">No
                                        </label>
                                    </div>
                                </div>
                                <div class="col-lg-12" style="border-bottom:1px solid #e9ecef"></div><br>
                                    <div class="row" id="ward_list">
                                        <div class="col-sm-3" id="">
                                        <div class="form-group">
                                            <label>Ward </label>
                                            <select class="form-control" name="ward_id" onchange="getBeds(this);">
                                                <option></option>
                                                <?php $get_wards = $this->treatmentm->get_ward_list();
                                                foreach($get_wards as $row){
                                                ?>
                                                <option value="<?php echo $row->ward_id?>"><?php echo $row->name?></option>
                                                <?php }?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-3" id="">
                                        <div class="form-group">
                                            <label>Bed <span class="text-danger">*</span></label>
                                            <select class="form-control" name="bed_id" id="bedsList">
                                                <option></option>
                                            </select>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                                </div>
                                <div class="m-t-20 text-center">
                                    <button class="btn btn-primary submit-btn">Submit</button>
                                </div>
                            </form>
                        </div>
					</div>
			</div>
				<div id="admit_patient" class="modal fade" role="dialog">
    			    <div class="modal-dialog modal-dialog-centered" style="max-width:900px">
        				<div class="modal-content">
                            <div class="modal-header">
                                <h5>Patient Details</h5>
                                <a class="btn btn-close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></a>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="card-box">
                                            <form action="#">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group row">
                                                            <label class="col-md-3 col-form-label"> Name</label>
                                                            <div class="col-md-9" id="">
                                                                <span id="patName"></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group row">
                                                            <label class="col-md-3 col-form-label"> Gender</label>
                                                            <div class="col-md-9">
                                                                <span id="genName"></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group row">
                                                            <label class="col-md-3 col-form-label"> Age</label>
                                                            <div class="col-md-9">
                                                                <span id="ageName"></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group row">
                                                            <label class="col-md-3 col-form-label"> Phone</label>
                                                            <div class="col-md-9">
                                                                <span id="phoneNum"></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group row">
                                                            <label class="col-md-3 col-form-label"> Address</label>
                                                            <div class="col-md-9">
                                                                <span id="addressName"></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group row">
                                                            <label class="col-md-3 col-form-label"> Email</label>
                                                            <div class="col-md-9">
                                                                <span id="emailName"></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row" style="border:1px solid #e9ecef;border-radius: 25px;">
                                                    <div class="col-md-12"><br>
                                                        <h5 class="text-center">Treatment Record</h5><br>
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-md-3 col-form-label"> Ward</label>
                                                                    <div class="col-md-9">
                                                                        <span id="wardName"></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-md-4 col-form-label"> Bed Number</label>
                                                                    <div class="col-md-8">
                                                                        <span id="bedNumber"></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-md-3 col-form-label"> Team Code</label>
                                                                    <div class="col-md-9">
                                                                        <span id="depName"></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group row">
                                                                    <label class="col-md-3 col-form-label"> Consultant Doctor</label>
                                                                    <div class="col-md-9">
                                                                        <span id="docName"></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group row">
                                                                    <label class="col-md-3 col-form-label"> Treated By Doctors</label>
                                                                    <div class="col-md-9">
                                                                        <div class="form-control form-check-inline" id="treatDocs"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            </div>
                                                            <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group row">
                                                                    <label class="col-md-3 col-form-label"> Treatment Started Date</label>
                                                                    <div class="col-md-9">
                                                                        <span id="treatDate"></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group row">
                                                                    <label class="col-md-3 col-form-label"> Admission Date</label>
                                                                    <div class="col-md-9">
                                                                        <span id="admissionDate"></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                            <input type="hidden" value="" id="patId">
                                            </form>
                                            <div class="m-t-20 text-right">
                                                <a href="#" data-toggle="modal" data-target="#edit_patient" data-id="" class="btn btn-primary btn-rounded"> Update</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="edit_patient" class="modal fade" role="dialog">
                    <div class="modal-dialog modal-dialog-centered" style="max-width:900px">
        				<div class="modal-content">
                            <div class="modal-header">
                                <h5>Update Patient</h5>
                                <a class="btn btn-close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></a>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="card-box">
                                            <form action="<?php echo base_url('treatment/update')?>" method="post">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group row">
                                                            <label class="col-md-3 col-form-label"> Name</label>
                                                            <div class="col-md-9" id="">
                                                                <input type="hidden" id="pat_id" name="pat_id" value="">
                                                                <span id="patName1"></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group row">
                                                            <label class="col-md-3 col-form-label"> Gender</label>
                                                            <div class="col-md-9">
                                                                <span id="genName1"></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group row">
                                                            <label class="col-md-3 col-form-label"> Age</label>
                                                            <div class="col-md-9">
                                                                <span id="ageName1"></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group row">
                                                            <label class="col-md-3 col-form-label"> Phone</label>
                                                            <div class="col-md-9">
                                                                <span id="phoneNum1"></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group row">
                                                            <label class="col-md-3 col-form-label"> Address</label>
                                                            <div class="col-md-9">
                                                                <span id="addressName1"></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group row">
                                                            <label class="col-md-3 col-form-label"> Email</label>
                                                            <div class="col-md-9">
                                                                <span id="emailName1"></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row" style="border:1px solid #e9ecef;border-radius: 25px;">
                                                    <div class="col-md-12"><br>
                                                        <h5 class="text-center">Treatment Record</h5><br>
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-md-3 col-form-label"> Ward</label>
                                                                    <div class="col-md-9">
                                                                        <select name="ward_id" class="form-control" id="wardList">
                                                                            <option></option>
                                                                        
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-md-4 col-form-label"> Bed Number</label>
                                                                    <div class="col-md-8">
                                                                        <span id="bedNumber1"></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-md-3 col-form-label"> Team Code</label>
                                                                    <div class="col-md-9">
                                                                        <span id="depName1"></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group row">
                                                                    <label class="col-md-3 col-form-label"> Doctor</label>
                                                                    <div class="col-md-6">
                                                                        <select name="doc_id" class="form-control" id="userList">
                                                                            <option></option>
                                                                        
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                            <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group row">
                                                                    <label class="col-md-3 col-form-label"> Treatment Started Date</label>
                                                                    <div class="col-md-9">
                                                                        <span id="treatDate1"></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group row">
                                                                    <label class="col-md-3 col-form-label"> Admission Date</label>
                                                                    <div class="col-md-6">
                                                                        <input type="date" class="form-control" name="admission_date" id="admissionDate1">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="m-t-20 text-center">
                                                    <button class="btn btn-primary submit-btn">Submit</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
    				
			</div>
    </div>
    <div class="sidebar-overlay" data-reff=""></div>
    <script src="<?php echo base_url('assets/js/jquery-3.2.1.min.js')?>"></script>
	<script src="<?php echo base_url('assets/js/popper.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/jquery.slimscroll.js')?>"></script>
    <script src="<?php echo base_url('assets/js/select2.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/jquery.dataTables.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/dataTables.bootstrap4.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/moment.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap-datetimepicker.min.js')?>"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $('#docs_list').hide();
            $('#beds_list').hide();
            $("#ward_list").hide();
        });
        function show_fields(){
            $('#docs_list').show();
            $('#beds_list').show();
            $('#usersList').empty();
            $('#bedsList').empty();
            var vall = document.getElementById("selected_id").value;
            //for doctors list
            $.ajax({
                type: 'GET',
                url: '<?php echo base_url("doctor/get_list")?>',
                contentType: "application/json",
                data: {'dep_id' : vall},
                success: function(result) {
                    parsedobj = JSON.parse(result)
                    var appenddata='';
                    appenddata+= "<option></option>";
                    $.each(parsedobj, function(index, value) 
                        {
                            appenddata += "<option value = '" + value.doc_id + "'>" + value.name + " </option>";    
                        });
                        $('#usersList').html(appenddata);
                }
            });
        }
        function show_form_yes(){
            var value1 = document.getElementById("yes").value;

            if(value1 == 1){
                $("#ward_list").show();
            }
            
        }
        function show_form_no(){
            var value2 = document.getElementById("no").value;
            
            if(value2 == 2){
                $("#ward_list").hide();
            }
        }
        
        $('#delete_patient').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget); 
            var id = button.data('id'); 
            $('#pat_idd').val(id);
            
        })
        
        function deleteRecord(){
            var pat_id = $('#pat_idd').val();
            
            $.ajax({
                type: 'GET',
                url: '<?php echo base_url("patient/discharge")?>',
                contentType: "application/json",
                data : {'pat_id': pat_id},
                success: function(result) {
                    alert("Patient Discharge Successfully");
                    window.location.reload();
                }
            });
        }
        
        $('#admit_patient').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget) 
            var id = button.data('id') 

            $.ajax({
                type: 'GET',
                url: '<?php echo base_url("patient/get_patient_details")?>',
                contentType: "application/json",
                data: {'pat_id' : id},
                success: function(result) {
                    parsedobj1 = JSON.parse(result);
                    // alert(parsedobj1);
                    var appenddata1='';
                    $('#patName').html();
                    $('#genName').html();
                    $('#ageName').html();
                    $('#phoneNum').html();
                    $('#addressName').html();
                    $('#emailName').html();
                    $('#wardName').html();
                    $('#bedNumber').html();
                    $('#depName').html();
                    $('#docName').html();
                    $('#treatDoc').html() ;
                    // $('#treatDate').html();
                    $('#admisisonDate').html();
                    $.each(parsedobj1, function(index, value) 
                        {
                            $("#patId").val(value.patient_id);
                            $("#patName").html(value.name);
                            if(value.gender == 1){
                                $("#genName").html('Male');
                            }else if(value.gender == 2){
                                $("#genName").html('Male');
                            }
                            $("#ageName").html(value.age);
                            $("#phoneNum").html(value.phone_number);
                            $("#addressName").html(value.permanent_address);
                            $("#emailName").html(value.email);
                            $("#wardName").html(value.ward_name);
                            $("#bedNumber").html(value.bed_number);
                            $("#depName").html(value.short_code);
                            $("#docName").html(value.doc_name);
                            // $("#treatDoc").html(value.doc_name);
                            $("#treatDate").html(value.created_date);
                            $("#admissionDate").html(value.admission_date);
                            
                            
                            $.ajax({
                                type: 'GET',
                                url: '<?php echo base_url("patient/get_list_docs")?>',
                                contentType: "application/json",
                                data : {'pat_id': id},
                                success: function(result) {
                                    parsedobj = JSON.parse(result)
                                    var appenddata='';
                                    appenddata+= "<option></option>";
                                    $.each(parsedobj, function(index, value1) 
                                        {
                                            appenddata+=value1.name+' , ';
                                        });
                                        $('#treatDocs').html(appenddata);
                                }
                            });
                            
                        });
                        
                }
               
            }); 
        
        })
        $('#edit_patient').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget) 
            var id = $("#patId").val() ;
            document.getElementById('pat_id').value = id;

            $.ajax({
                type: 'GET',
                url: '<?php echo base_url("patient/get_patient_details")?>',
                contentType: "application/json",
                data: {'pat_id' : id},
                success: function(result) {
                    parsedobj1 = JSON.parse(result);
                    // alert(parsedobj1);
                    var appenddata1='';
                    $('#patName1').html();
                    $('#genName1').html();
                    $('#ageName1').html();
                    $('#phoneNum1').html();
                    $('#addressName1').html();
                    $('#emailName1').html();
                    $('#wardName1').val();
                    $('#bedNumber1').html();
                    $('#depName1').html();
                    $('#docName1').val();
                    $('#treatDoc1').html() ;
                    $('#treatDate1').html();
                    $('#admissionDate1').html();
                    $.each(parsedobj1, function(index, value) 
                        {
                            // $('#pat_id').val(value.patient_id);
                            $("#patName1").html(value.name);
                            $("#genName1").html(value.gender);
                            $("#ageName1").html(value.age);
                            $("#phoneNum1").html(value.phone_number);
                            $("#addressName1").html(value.permanent_address);
                            $("#emailName1").html(value.email);
                            // var wardIID = document.getElementById("wardId").value;
                            // if(wardIID == value.ward_id){
                            // $("#idWard").attr("selected", true);
                            // }
                            $("#bedNumber1").html(value.bed_number);
                            $("#depName1").html(value.short_code);
                            $("#treatDoc1").html(value.doc_name);
                            $("#treatDate1").html(value.created_date);
                            $("#admissionDate1").val(value.admission_date);
                            
                            
                        $.ajax({
                            type: 'GET',
                            url: '<?php echo base_url("doctor/get_list")?>',
                            contentType: "application/json",
                            data : {'dep_id': ''},
                            success: function(result) {
                                parsedobj = JSON.parse(result)
                                var appenddata='';
                                appenddata+= "<option></option>";
                                $.each(parsedobj, function(index, value1) 
                                    {
                                        selectedValue = value.doctor_id;
                                        if(value1.doc_id == selectedValue){var opt = 'Selected="selected"';};
                                        appenddata += "<option value = '" + value1.doc_id + "'"+opt+">" + value1.name + " </option>";    
                                    });
                                    $('#userList').html(appenddata);
                            }
                        });
                        
                        $.ajax({
                            type: 'GET',
                            url: '<?php echo base_url("treatment/get_ward_list")?>',
                            contentType: "application/json",
                            success: function(result) {
                                parsedobj = JSON.parse(result)
                                var appenddata='';
                                appenddata+= "<option></option>";
                                $.each(parsedobj, function(index, value2) 
                                    {
                                        selectedValue = value.ward_id;
                                        if(value2.ward_id == selectedValue){var opt = 'Selected="selected"';};
                                        appenddata += "<option value = '" + value2.ward_id + "'"+opt+">" + value2.name + " </option>";    
                                    });
                                    $('#wardList').html(appenddata);
                            }
                        });
                            
                        });
                        
                }
                 
            }); 
            
            
            
        
        })
        
        function getBeds(ward){
            $.ajax({
                type: 'GET',
                url: '<?php echo base_url("department/get_beds_list")?>',
                contentType: "application/json",
                data: {'ward_id' : ward.value},
                success: function(result) {
                    parsedobj1 = JSON.parse(result)
                    var appenddata1='';
                    appenddata1+= "<option></option>";
                    $.each(parsedobj1, function(index, value) 
                        {
                            appenddata1 += "<option value = '" + value.bed_id + "'>" + value.bed_number + " </option>";    
                        });
                        $('#bedsList').html(appenddata1);
                }
            });
        }
        
        $('#DataTables_Table_0').DataTable({
            searching: true, // Ensure this is true
            pagging : true
        });
    </script>
    <!--<script src="<?php echo base_url('assets/js/app.js')?>"></script>-->
</body>


<!-- patients23:19-->
</html>