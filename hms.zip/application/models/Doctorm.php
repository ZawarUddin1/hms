<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Doctorm extends CI_Model
{

    function __construct() {
        parent::__construct();
        $this->load->database();
    }

    function __destruct() {
        $this->db->close();
    }

    public function get_list($dep_id = false){
        $this->db->select('D.*,DP.name as dep_name');
        $this->db->from('doctors as D');
        $this->db->join('departments as DP','DP.doctor_id = D.doc_id','left');
        $this->db->where('D.status','1');
        $this->db->group_by('D.doc_id');
        if($dep_id){
            $this->db->where('D.dep_id',$dep_id);
        }
        $query = $this->db->get();
        return $query->result();
    }

    public function add_doctor($data){
        $this->db->insert('doctors',$data);
        return true;
    }
    
    public function get_dep_list(){
        $this->db->select('*');
        $this->db->from('departments');
        $query = $this->db->get();
        return $query->result();
    }
}
?>