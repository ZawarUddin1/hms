<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboardm extends CI_Model
{

    function __construct() {
        parent::__construct();
        $this->load->database();
    }

    function __destruct() {
        $this->db->close();
    }
    
    public function get_tot_docs(){
        $this->db->select('count(doc_id) as tot_docs');
        $this->db->from('doctors');
        $this->db->where('status',1);
        $query = $this->db->get();
        return $query->result();
    }
    
    public function get_tot_pat(){
        $this->db->select('count(patient_id) as tot_pats');
        $this->db->from('patients');
        $this->db->where('status',1);
        $query = $this->db->get();
        return $query->result();
    }
    
    public function get_tot_deps(){
        $this->db->select('count(dep_id) as tot_deps');
        $this->db->from('departments');
        $this->db->where('status',1);
        $query = $this->db->get();
        return $query->result();
    }
    
    public function get_tot_admits(){
        $this->db->select('count(treatment_id) as tot_admits');
        $this->db->from('treatment_record');
        $query = $this->db->get();
        return $query->result();
    }
    
    public function get_new_patients(){
        $date = date('Y-m-d');
        $this->db->select('*');
        $this->db->from('patients');
        $this->db->where('created_date BETWEEN DATE_SUB(NOW(), INTERVAL 5 DAY) AND NOW()');
        $query = $this->db->get();
        return $query->result();
    }
}
?>