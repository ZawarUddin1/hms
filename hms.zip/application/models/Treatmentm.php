<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Treatmentm extends CI_Model
{

    function __construct() {
        parent::__construct();
        $this->load->database();
    }

    function __destruct() {
        $this->db->close();
    }
    
    public function get_list($dep_id = false, $doc_id = false){
        $this->db->select('TR.*,P.name as patient,B.bed_number as bed,P.admission_date as admission,D.name as doctor,DP.name as dep');
        $this->db->from('treatment_record as TR');
        $this->db->join('patients as P','P.treatment_id = TR.treatment_id');
        $this->db->join('doctors as D','D.doc_id = TR.doctor_id');
        $this->db->join('beds as B','B.bed_id = TR.bed_id');
        $this->db->join('departments as DP','DP.dep_id = B.ward_id');
        if($dep_id > 0 && $doc_id > 0){
            $this->db->where('DP.dep_id',$dep_id);
            $this->db->where('TR.doctor_id',$doc_id);
        }
        elseif($dep_id > 0 && $doc_id <= 0){
            $this->db->where('DP.dep_id',$dep_id);
        }
        elseif($doc_id > 0 && $dep_id <= 0){
            $this->db->where('TR.doctor_id',$doc_id);
        }
        $query = $this->db->get();
        return $query->result();
    }
    
    public function get_wards_list(){
        $this->db->select('W.*,D.name as dep_name,DD.name as doc_name');
        $this->db->from('wards as W');
        $this->db->join('departments as D','D.dep_id = W.dep_id','left');
        $this->db->join('doctors as DD','DD.doc_id = D.doctor_id','left');
        $query = $this->db->get();
        return $query->result();
    }
    
    public function get_ward_list(){
        $this->db->select('*');
        $this->db->from('wards');
        $query = $this->db->get();
        return $query->result();
    }
    
    public function update_tr($data){
        $this->db->insert('treatment_record',$data);
        return true;
    }
    
    public function update_pat($patient_id,$ward_id,$tr_id,$bed_id,$admission){
        $query = "Update patients set bed_id = '$bed_id', treatment_id = '$tr_id', ward_id = '$ward_id', admission_date = '$admission' where patient_id = '$patient_id'";
        if($this->db->query($query)){
            return true;
        }
    }
    
    public function get_details($ward_id){
        $this->db->select('*');
        $this->db->from('wards');
        $this->db->where('ward_id',$ward_id);
        $query = $this->db->get();
        return $query->row();
    }
    
    public function get_patients($ward_id){
        $this->db->select('*');
        $this->db->from('patients');
        $this->db->where('ward_id',$ward_id);
        $query = $this->db->get();
        return $query->result();
    }
}
?>