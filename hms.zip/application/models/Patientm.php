<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Patientm extends CI_Model
{

    function __construct() {
        parent::__construct();
        $this->load->database();
    }

    function __destruct() {
        $this->db->close();
    }

    public function get_list(){
        $this->db->select('*');
        $this->db->from('patients');
        $this->db->where('status','1');
        $this->db->order_by('created_date','asc');
        $query = $this->db->get();
        return $query->result();
    }

    public function add_patient($data){
        $this->db->insert('patients',$data);
        return true;
    }
    
    public function get_list_(){
        $this->db->select('*');
        $this->db->from('patients');
        // $this->db->join('treatment_record as TR','TR.patient_id = patients.patient_id','left');
        $this->db->where('treatment_id = ','0'); 
        $this->db->where('status','1');
        $this->db->order_by('patients.created_date','asc');
        $query = $this->db->get();
        return $query->result();
    }
    
    public function update_pat($patient_id,$admission_date,$bed_id,$treatment_id){
        $query = "Update patients set admission_date = '$admission_date', bed_id = '$bed_id', treatment_id = '$treatment_id' where patient_id = '$patient_id'";
        if($this->db->query($query)){
            return true;
        }
    }
    
    public function get_patient_details($pat_id){
        $this->db->select('P.*,B.bed_number,W.name as ward_name,DD.short_code,TR.doctor_id,TR.created_date');
        $this->db->from('patients as P');
        $this->db->join('wards AS W','W.ward_id = P.ward_id','left');
        $this->db->join('beds as B','B.bed_id = P.bed_id','left');
        $this->db->join('treatment_record as TR','TR.treatment_id = P.treatment_id','left');
        $this->db->join('doctors as D','D.doc_id = TR.doctor_id','left');
        $this->db->join('departments as DD','DD.dep_id = D.dep_id');
        $this->db->where('P.patient_id',$pat_id);
        
        $query = $this->db->get();
        return $query->result();
    }
    
    public function get_list_docs($pat_id){
        $this->db->select('D.name');
        $this->db->from('treatment_record as TR');
        $this->db->join('doctors as D','TR.doctor_id = D.doc_id','left');
        $this->db->where('TR.patient_id',$pat_id);
        $this->db->group_by('TR.doctor_id');
        $query = $this->db->get();
        return $query->result();
    }
    
    public function get_pat_ward($ward_id){
        $this->db->select('ward_id');
        $this->db->from('patients');
        $this->db->where('ward_id',$ward_id);
        $query = $this->db->get();
        return $query->row();
    }
}
?>