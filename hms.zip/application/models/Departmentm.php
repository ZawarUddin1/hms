<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Departmentm extends CI_Model
{

    function __construct() {
        parent::__construct();
        $this->load->database();
    }

    function __destruct() {
        $this->db->close();
    }

    public function get_list(){
        $this->db->select('departments.*,doctors.name as incharge');
        $this->db->from('departments');
        // $this->db->join('beds','departments.dep_id = beds.ward_id');
        $this->db->join('doctors','departments.doctor_id = doctors.doc_id');
        // $this->db->where('status','1');
        $this->db->order_by('departments.name','acs');
        $this->db->group_by('departments.name');
        $query = $this->db->get();
        return $query->result();
    }
    
    public function get_list_for_patients(){
        $this->db->select('*');
        $this->db->from('departments');
        $this->db->join('beds','departments.dep_id = beds.ward_id');
        $this->db->where('beds.status','1');
        $this->db->order_by('name','acs');
        $this->db->group_by('name');
        $query = $this->db->get();
        return $query->result();
    }

    public function add_department($data){
        $this->db->insert('departments',$data);
        return true;
    }

    public function add_bed($data){
        $this->db->insert('beds', $data);
        return true;
    }

    public function get_tot_beds($dep_id){
        $this->db->select('count(bed_number) as tot_bed');
        $this->db->from('beds');
        $this->db->where('ward_id',$dep_id);
        $query = $this->db->get();
        return $query->result();
    }
    
    public function get_beds_list($dep_id){
        $sql = 'SELECT  *  FROM  beds WHERE bed_id NOT IN (SELECT  bed_id from treatment_record) and ward_id = '.$dep_id;
        if($this->db->query($sql)){
            return $this->db->query($sql)->result();
        }
        // $this->db->select('*');
        // $this->db->from('beds');
        // $this->db->join('treatment_record as TR','TR.bed_id = beds.bed_id','left');
        // $this->db->where('ward_id',$dep_id);
        // $this->db->where('TR.bed_id IS 0');
        // $query = $this->db->get();
        // return $query->result();
    }
}
?>