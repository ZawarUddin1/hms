<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Loginm extends CI_Model
{

    function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function validate($name,$password) {
        $this->db->select('users.*,admin.right_id as admin_right_id,doctors.right_id as doctor_right_id,patients.right_id as patient_right_id');
        $this->db->from('users');
        $this->db->join('admin','admin.user_id = users.user_id','left');
        $this->db->join('doctors','doctors.user_id = users.user_id','left');
        $this->db->join('patients','patients.user_id = users.user_id','left');
        $this->db->where('users.username',$name);
        $this->db->where('password',$password);
        $query = $this->db->get();
        return $query->row();
    }

    public function insert($data) {
        $query = $this->db->insert("users",$data);
        if ($query) {
            return true;
        } else {
            return false;
        }
    }
    function __destruct() {
        $this->db->close();
    }
}
?>